def handler2(event, context):
    print("Hello world!")
