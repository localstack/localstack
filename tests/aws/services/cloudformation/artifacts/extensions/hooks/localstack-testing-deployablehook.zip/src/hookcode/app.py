def handler(event, ctx):
    request_token = event["clientRequestToken"]
    invocation_point = event["actionInvocationPoint"]

    if invocation_point in ["CREATE_PRE_PROVISION", "UPDATE_PRE_PROVISION"]:
        return {
            'errorCode': 'InternalFailure',
            'message': 'Intentional fail',
            'callbackDelaySeconds': 0,
            'clientRequestToken': request_token,
            'hookStatus': 'FAILED'
        }
    else:
        return {
            'message': '',
            'callbackDelaySeconds': 0,
            'clientRequestToken': request_token,
            'hookStatus': 'SUCCESS'
        }
