import logging

def handler(
        event, ctx
):
    return {
        "message": "",
        "callbackDelaySeconds": 0,
        "resourceModel": {
            "Name": "Test"
        },
        "status": "FAILED"
    }