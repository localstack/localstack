import settings

constant = settings.SETTING1


def handler(event, context):
    return constant
