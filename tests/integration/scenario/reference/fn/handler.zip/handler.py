def handler(event, context):
    return {"hello": "world"}
